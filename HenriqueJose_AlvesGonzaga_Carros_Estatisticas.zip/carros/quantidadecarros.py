# Quantos carros existem?
def quantidadecarros(lista):
    return len(lista)
